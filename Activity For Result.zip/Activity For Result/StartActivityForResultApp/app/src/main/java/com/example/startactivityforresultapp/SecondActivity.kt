package com.example.startactivityforresult

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    private lateinit var inputEditText: EditText
    private lateinit var returnButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        inputEditText = findViewById(R.id.editTextUserInput)
        returnButton = findViewById(R.id.buttonReturnData)

        returnButton.setOnClickListener {
            val inputText = inputEditText.text.toString().trim()

            if (inputText.isEmpty()) {
                Toast.makeText(this, "Please enter some text", Toast.LENGTH_SHORT).show()
            } else if (!inputText.matches(Regex("^[a-zA-Z ]+$"))) {
                Toast.makeText(this, "Only letters and spaces allowed", Toast.LENGTH_SHORT).show()
            } else {
                val resultIntent = Intent()
                resultIntent.putExtra("user_input", inputText)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            }
        }
    }
}
